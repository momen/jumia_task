<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BaseModel extends Model{

    /// this class will extends with all models so in some time we can
    /// share some logic in all model

}
